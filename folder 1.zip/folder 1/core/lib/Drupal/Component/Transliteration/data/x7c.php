<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ze', 'shai', 'gui', 'yi', 'hu', 'chan', 'kou', 'cu', 'ping', 'zao', 'ji', 'gui', 'su', 'lou', 'ce', 'lu',
  0x10 => 'nian', 'suo', 'cuan', 'diao', 'suo', 'le', 'duan', 'liang', 'xiao', 'bo', 'mi', 'shai', 'dang', 'liao', 'dan', 'dian',
  0x20 => 'fu', 'jian', 'min', 'kui', 'dai', 'jiao', 'deng', 'huang', 'sun', 'lao', 'zan', 'xiao', 'lu', 'shi', 'zan', 'qi',
  0x30 => 'pai', 'qi', 'pai', 'gan', 'ju', 'du', 'lu', 'yan', 'bo', 'dang', 'sai', 'zhua', 'long', 'qian', 'lian', 'bu',
  0x40 => 'zhou', 'lai', 'shi', 'lan', 'kui', 'yu', 'yue', 'hao', 'zhen', 'tai', 'ti', 'nie', 'chou', 'ji', 'yi', 'qi',
  0x50 => 'teng', 'zhuan', 'zhou', 'fan', 'sou', 'zhou', 'qian', 'zhuo', 'teng', 'lu', 'lu', 'jian', 'tuo', 'ying', 'yu', 'lai',
  0x60 => 'long', 'qie', 'lian', 'lan', 'qian', 'yue', 'zhong', 'qu', 'lian', 'bian', 'duan', 'zuan', 'li', 'si', 'luo', 'ying',
  0x70 => 'yue', 'zhuo', 'yu', 'mi', 'di', 'fan', 'shen', 'zhe', 'shen', 'nu', 'he', 'lei', 'xian', 'zi', 'ni', 'cun',
  0x80 => 'zhang', 'qian', 'zhai', 'bi', 'ban', 'wu', 'sha', 'kang', 'rou', 'fen', 'bi', 'cui', 'yin', 'zhe', 'chi', 'tai',
  0x90 => 'hu', 'ba', 'li', 'gan', 'ju', 'po', 'mo', 'cu', 'zhan', 'zhou', 'li', 'su', 'tiao', 'li', 'xi', 'su',
  0xA0 => 'hong', 'tong', 'zi', 'ce', 'yue', 'zhou', 'lin', 'zhuang', 'bai', 'lao', 'fen', 'er', 'qu', 'he', 'liang', 'xian',
  0xB0 => 'fu', 'liang', 'can', 'jing', 'li', 'yue', 'lu', 'ju', 'qi', 'cui', 'bai', 'zhang', 'lin', 'zong', 'jing', 'guo',
  0xC0 => 'hua', 'san', 'san', 'tang', 'bian', 'rou', 'mian', 'hou', 'xu', 'zong', 'hu', 'jian', 'zan', 'ci', 'li', 'xie',
  0xD0 => 'fu', 'nuo', 'bei', 'gu', 'xiu', 'gao', 'tang', 'qiu', 'jia', 'cao', 'zhuang', 'tang', 'mi', 'san', 'fen', 'zao',
  0xE0 => 'kang', 'jiang', 'mo', 'san', 'san', 'nuo', 'xi', 'liang', 'jiang', 'kuai', 'bo', 'huan', 'shu', 'zong', 'xian', 'nuo',
  0xF0 => 'tuan', 'nie', 'li', 'zuo', 'di', 'nie', 'tiao', 'lan', 'mi', 'si', 'jiu', 'xi', 'gong', 'zheng', 'jiu', 'you',
];
